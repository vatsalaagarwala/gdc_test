<div class="col-md-3 col-sm-3 side-nav" id="leftCol">
        <div class="user-photo">
        
          <img alt="User Photo" src="<?php echo e(URL::to(Auth::user()->image_icon)); ?>">
          
        </div>
        <div class="hide-side">
          <ul class="listnone nav" id="sidebar">
            <li class="<?php echo e(classActivePathSite('dashboard')); ?>"><a href="<?php echo e(URL::to('dashboard')); ?>"><i class="fa fa-tachometer"></i> Dashboard</a></li>            
            <li class="<?php echo e(classActivePathSite('profile')); ?>"><a href="<?php echo e(URL::to('profile')); ?>"><i class="fa fa-user"></i> Edit Profile</a></li>
            <li class="<?php echo e(classActivePathSite('change_pass')); ?>"><a href="<?php echo e(URL::to('change_pass')); ?>"><i class="fa fa-key"></i> Change Password</a></li>
            
            <li class="<?php echo e(classActivePathSite('mylisting')); ?>"><a href="<?php echo e(URL::to('mylisting')); ?>"><i class="fa fa-map-marker"></i> My Listing</a></li>

            <li ><a href="<?php echo e(URL::to('membership')); ?>"><i class="fa fa-money"></i> Membership Plan</a></li>

            <li class="<?php echo e(classActivePathSite('submit_listing')); ?>"><a href="<?php echo e(URL::to('submit_listing')); ?>"><i class="fa fa-plus"></i> Submit Listing</a></li>
            
            <li><a href="<?php echo e(URL::to('logout')); ?>"><i class="fa fa-sign-out"></i> Logout</a></li>
          </ul>
        </div>
      </div>