<?php $__env->startSection('head_title', 'Search Listings | '.getcong('site_name') ); ?>

<?php $__env->startSection('head_url', Request::url()); ?>

<?php $__env->startSection('content'); ?>

<div class="tp-page-head" style="background:url(<?php echo e(URL::asset('upload/'.getcong('page_bg_image'))); ?>) no-repeat">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-header">
          <h1>Search</h1>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="tp-breadcrumb">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
          <li class="active">Search</li>
        </ol>
      </div>
    </div>
  </div>
</div>
<div class="main-container">
  <div class="container">
    <div class="row">
  
  <?php echo $__env->make("_particles.sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>     

 <div class="col-md-9 col-sm-8">
        <div class="row">
          
          <?php foreach($listings as $listing): ?> 
          <div class="col-md-4 vendor-box" style="min-height:410px;">
            <div class="vendor-image"> <a href="<?php echo e(URL::to('listings/'.$listing->listing_slug.'/'.$listing->id)); ?>"><img src="<?php echo e(URL::asset('upload/listings/'.$listing->featured_image.'-s.jpg')); ?>" class="img-responsive"></a>
               
            </div>
            <div class="vendor-detail">
              <div class="caption">
                <h2><a href="<?php echo e(URL::to('listings/'.$listing->listing_slug.'/'.$listing->id)); ?>" class="title"><?php echo e($listing->title); ?></a></h2>
                <p class="location" style="min-height:42px;"><?php echo e(str_limit($listing->address,50)); ?></p>
                <div class="rating"> 
                  <?php for($x = 0; $x < 5; $x++): ?>
                  
                    <?php if($x < $listing->review_avg): ?>
                      <i class="fa fa-star"></i>
                    <?php else: ?>
                      <i class="fa fa-star-o"></i>
                    <?php endif; ?>
                   
                    <?php endfor; ?>
                    <span class="rating-count">(<?php echo e(\App\Reviews::getTotalReview($listing->id)); ?>)</span> 
                </div>
              </div>
              
              <div class="clearfix"></div>
            </div>
          </div>
          <?php endforeach; ?>

         
            
        </div>
      </div>
    </div>
  </div>
</div>

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>