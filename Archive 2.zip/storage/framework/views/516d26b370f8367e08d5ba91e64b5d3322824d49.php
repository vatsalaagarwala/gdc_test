<?php $__env->startSection("content"); ?>

                <!-- Page Header -->
                <div class="content bg-gray-lighter">
                    <div class="row items-push">
                        <div class="col-sm-7">
                            <h1 class="page-heading">
                               <?php echo e(isset($user->id) ? 'Edit User' : 'Add User'); ?>

                            </h1>
                        </div>
                        <div class="col-sm-5 text-right hidden-xs">
                            <ol class="breadcrumb push-10-t">
                                <li><a href="<?php echo e(URL::to('admin/users')); ?>">Users</a></li>
                                <li><a class="link-effect" href=""><?php echo e(isset($user->id) ? 'Edit User' : 'Add User'); ?></a></li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- END Page Header -->

                <!-- Page Content -->
                <div class="content content-boxed">
                    <div class="row">
                        <div class="col-sm-12 col-lg-12">
                            <div class="block">
                               <div class="block-content block-content-narrow"> 
                                <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <ul>
                                        <?php foreach($errors->all() as $error): ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                <?php endif; ?>
                                 <?php if(Session::has('flash_message')): ?>
                                                <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                                                    <?php echo e(Session::get('flash_message')); ?>

                                                </div>
                                <?php endif; ?>
                                <?php echo Form::open(array('url' => array('admin/users/adduser'),'class'=>'form-horizontal padding-15','name'=>'user_form','id'=>'user_form','role'=>'form','enctype' => 'multipart/form-data')); ?> 
                <input type="hidden" name="id" value="<?php echo e(isset($user->id) ? $user->id : null); ?>">
                  
                
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">First Name</label>
                    <div class="col-sm-9">
                        <input type="text" name="first_name" value="<?php echo e(isset($user->first_name) ? $user->first_name : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Last Name</label>
                    <div class="col-sm-9">
                        <input type="text" name="last_name" value="<?php echo e(isset($user->last_name) ? $user->last_name : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input type="text" name="email" value="<?php echo e(isset($user->email) ? $user->email : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" name="password" value="" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Mobile</label>
                    <div class="col-sm-9">
                        <input type="text" name="mobile" value="<?php echo e(isset($user->mobile) ? $user->mobile : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Contact Email</label>
                    <div class="col-sm-9">
                        <input type="text" name="contact_email" value="<?php echo e(isset($user->contact_email) ? $user->contact_email : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Website</label>
                    <div class="col-sm-9">
                        <input type="text" name="website" value="<?php echo e(isset($user->website) ? $user->website : null); ?>" class="form-control">
                    </div>
                </div>
                 <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Address</label>
                    <div class="col-sm-9">
                        
                        <textarea name="address" cols="30" rows="5" class="form-control"><?php echo e(isset($user->address) ? $user->address : null); ?></textarea>
                    </div>
                </div>

                <hr>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Facebook Url</label>
                    <div class="col-sm-9">
                        <input type="text" name="facebook_url" value="<?php echo e(isset($user->facebook_url) ? $user->facebook_url : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Twitter Url</label>
                    <div class="col-sm-9">
                        <input type="text" name="twitter_url" value="<?php echo e(isset($user->twitter_url) ? $user->twitter_url : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Linkedin Url</label>
                    <div class="col-sm-9">
                        <input type="text" name="linkedin_url" value="<?php echo e(isset($user->linkedin_url) ? $user->linkedin_url : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Dribbble Url</label>
                    <div class="col-sm-9">
                        <input type="text" name="dribbble_url" value="<?php echo e(isset($user->dribbble_url) ? $user->dribbble_url : null); ?>" class="form-control">
                    </div>
                </div>
                <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Instagram Url</label>
                    <div class="col-sm-9">
                        <input type="text" name="instagram_url" value="<?php echo e(isset($user->instagram_url) ? $user->instagram_url : null); ?>" class="form-control">
                    </div>
                </div>
                <hr>
                 
                <div class="form-group">
                    <label for="avatar" class="col-sm-3 control-label">Profile Picture</label>
                    <div class="col-sm-9">
                        <div class="media">
                            <div class="media-left">
                                <?php if(isset($user->image_icon)): ?>
                                 
                                    <img src="<?php echo e(URL::to($user->image_icon)); ?>" width="100" alt="person">
                                <?php endif; ?>
                                                                
                            </div>
                            <div class="media-body media-middle">
                                <input type="file" name="image_icon" class="filestyle"> 
                            </div>
                        </div>
    
                    </div>
                </div>                  
                <hr>
                <div class="form-group">
                    <div class="col-md-offset-3 col-sm-9 ">
                        <button type="submit" class="btn btn-primary"><?php echo e(isset($user->id) ? 'Edit User' : 'Add User'); ?></button>
                         
                    </div>
                </div>
                
                <?php echo Form::close(); ?> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END Page Content -->     

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.admin_app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>