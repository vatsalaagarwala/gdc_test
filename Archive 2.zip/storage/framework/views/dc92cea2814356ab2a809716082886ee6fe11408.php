<?php $__env->startSection('content'); ?>

<?php echo $__env->make("_particles.slider_search", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

<div id="featured-list" class="featured-listing">
  <div class="container">
    <div class="row clearfix">
      <h2 style="color: black;"><strong>Freatured</strong> Listing</h2>
      <?php foreach(\App\Listings::where(array('featured_listing'=>'1','status'=>'1'))->orderBy('id')->get() as $featured_listing): ?>
      <div class="col-md-3 col-sm-4 col-xs-6 hi-icon-effect-8">
        <div class="single-product">
          <figure> <img alt="" src="<?php echo e(URL::asset('upload/listings/'.$featured_listing->featured_image.'-s.jpg')); ?>">
            <div class="rating">
              <ul class="list-inline">
                <?php for($x = 0; $x < 5; $x++): ?>
                  
                <?php if($x < $featured_listing->review_avg): ?>
                  <li><a href="#"><i class="fa fa-star"></i></a></li>
                <?php else: ?>
                  <li><a href="#"><i class="fa fa-star-o"></i></a></li>
                <?php endif; ?>
               
                <?php endfor; ?>
                
              </ul>
              <p>Featured</p>
            </div>
            <figcaption>
              <div class="read-more"> <a href="<?php echo e(URL::to('listings/'.$featured_listing->listing_slug.'/'.$featured_listing->id)); ?>"><i class="fa fa-angle-right"></i> Read More</a> </div>
            </figcaption>
          </figure>
          <h4><a href="<?php echo e(URL::to('listings/'.$featured_listing->listing_slug.'/'.$featured_listing->id)); ?>"><?php echo e($featured_listing->title); ?></a></h4>
           <p class="location" style="min-height: 50px;"><?php echo e(str_limit($featured_listing->address,50)); ?></p>
        </div>
      </div>
      <?php endforeach; ?>
       
    </div>
  </div>
</div>


<div class="spacer feature-section classifieds-content">
  <div class="container">



    <?php /* <div class="heading-section clearfix">
      <h1>Classifieds Categories</h1>
       
    </div>

    <div class="row">
      <div class="col-md-12">
        <ul class="classifieds-category">
          <?php foreach(\App\Categories::orderBy('category_name')->get() as $cat): ?>
          <li>
            <a href="<?php echo e(URL::to($cat->category_slug.'/'.$cat->id)); ?>"><i class="fa <?php echo e($cat->category_icon); ?>"></i><?php echo e($cat->category_name); ?> <span>(<?php echo e(\App\Categories::countCategoryListings($cat->id)); ?>)</span></a>
            <ul class="sub-category">
              <?php foreach(\App\SubCategories::where('cat_id',$cat->id)->orderBy('sub_category_name')->get() as $subcat): ?>
              <li><a href="<?php echo e(URL::to($cat->category_slug.'/'.$subcat->sub_category_slug.'/'.$subcat->id)); ?>"><?php echo e($subcat->sub_category_name); ?> <span>(<?php echo e(\App\SubCategories::countSubCategoryListings($subcat->id)); ?>)</span></a></li>
              <?php endforeach; ?>
               
            </ul>
          </li>
          <?php endforeach; ?>
           
        </ul>
      </div>
       
    </div> */ ?>

    
  </div>
</div>


 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>