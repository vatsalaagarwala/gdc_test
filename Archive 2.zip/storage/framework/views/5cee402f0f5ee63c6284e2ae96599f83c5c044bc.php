 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type"content="text/html;charset=UTF-8"/>
    <meta name="viewport"content="width=device-width, initial-scale=1.0">
    
    <title><?php echo $__env->yieldContent('head_title', getcong('site_name')); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('head_description', getcong('site_description')); ?>" />

    <meta property="og:type" content="article" />
    <meta property="og:title" content="<?php echo $__env->yieldContent('head_title',  getcong('site_name')); ?>" />
    <meta property="og:description" content="<?php echo $__env->yieldContent('head_description', getcong('site_description')); ?>" />
    <meta property="og:image" content="<?php echo $__env->yieldContent('head_image', url('/upload/logo.png')); ?>" />
    <meta property="og:url" content="<?php echo $__env->yieldContent('head_url', url('/')); ?>" />
 
    
 
    <link href="<?php echo e(URL::asset('site_assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('site_assets/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('site_assets/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('site_assets/css/owl.theme.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('site_assets/css/owl.transitions.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('site_assets/css/bootstrap-select.min.css')); ?>">
    <link href='https://fonts.googleapis.com/css?family=Dosis:400,500,600,700,800,300,200' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,400italic,600,700,800,600italic,700italic' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo e(URL::asset('site_assets/css/font-awesome.min.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(URL::asset('upload/'.getcong('site_favicon'))); ?>" type="image/x-icon">
</head>
<body>

    <?php echo $__env->make("_particles.header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
    <?php echo $__env->yieldContent("content"); ?>

    <?php echo $__env->make("_particles.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 
 <?php if(!classActivePathSite('submit_listing')): ?><!-- Page Plugins -->
<script src="<?php echo e(URL::asset('site_assets/js/jquery.min.js')); ?>"></script>
<?php endif; ?>

<script src="<?php echo e(URL::asset('site_assets/js/bootstrap.min.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('site_assets/js/nav.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(URL::asset('site_assets/js/bootstrap-select.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('site_assets/js/owl.carousel.min.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(URL::asset('site_assets/js/thumbnail-slider.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('site_assets/js/slider.js')); ?>"></script> 
<script type="text/javascript" src="<?php echo e(URL::asset('site_assets/js/testimonial.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('site_assets/js/jquery.sticky.js')); ?>"></script> 
<script src="<?php echo e(URL::asset('site_assets/js/header-sticky.js')); ?>"></script>

<?php if(!classActivePathSite('submit_listing')): ?><!-- Page Plugins -->
<script src="<?php echo e(URL::asset('site_assets/js/fileinput.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('site_assets/js/superlist.js')); ?>"></script>
<?php endif; ?>

<!--<script src="<?php echo e(URL::asset('site_assets/js/fileinput.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('site_assets/js/jquery.colorbox-min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('site_assets/js/superlist.js')); ?>"></script>-->
</body>
</html>