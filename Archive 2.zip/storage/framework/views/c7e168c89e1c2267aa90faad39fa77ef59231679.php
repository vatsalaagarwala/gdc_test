

<?php $__env->startSection('head_title', 'My Listing | '.getcong('site_name') ); ?>

<?php $__env->startSection('head_url', Request::url()); ?>

<?php $__env->startSection("content"); ?>

 <div class="tp-page-head" style="background:url(<?php echo e(URL::asset('upload/'.getcong('page_bg_image'))); ?>) no-repeat">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-header">
          <h1>My Listing</h1>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="tp-breadcrumb">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="#">Home</a></li>
          <li class="active">My Listing</li>
        </ol>
      </div>
    </div>
  </div>
</div>
<div class="main-container">
  <div class="container">
    <div class="row">
      
      <?php echo $__env->make("_particles.user_sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

     <div class="col-md-9 col-sm-9 content-right">
        <div class="row">
          <div class="col-md-12" id="aboutus">
            <h1>My Listing</h1> 

            <?php if(Session::has('flash_message')): ?>
                    <div class="alert alert-success">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button>
                        <?php echo e(Session::get('flash_message')); ?>

                    </div>
          <?php endif; ?>

        <div class="well-box">
          
          <table class="table table-bordered mb0">
          <thead>
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
          </thead>
          <tbody>
          <?php foreach($listings as $i => $listing): ?>
          <tr>
            <th scope="row"><?php echo e($i+1); ?></th>
            <td><?php echo e($listing->title); ?></td>
            <td>
              <?php if($listing->status=='0'): ?>
                 <span class="label label-danger">Pending</span>
              <?php else: ?>
                  <span class="label label-success">Publish</span>
              <?php endif; ?>
            </td>
            <td>
              <a href="<?php echo e(URL::to('submit_listing/'.$listing->id)); ?>" class="btn btn-info">Edit</a> 
              <a href="<?php echo e(URL::to('delete_listing/'.$listing->id)); ?>" class="btn btn-danger">Delete</a>
              </td>
          </tr>
          <?php endforeach; ?>
      
          
           
                  
          </tbody>
        </table>
        
        <div class="span12 pagination-center">
          <div class="dataTables_paginate paging_bootstrap pagination">
           
            <?php echo $__env->make('_particles.pagination', ['paginator' => $listings], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           
          </div>
        </div>
        <div class="clearfix"></div>
        </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>