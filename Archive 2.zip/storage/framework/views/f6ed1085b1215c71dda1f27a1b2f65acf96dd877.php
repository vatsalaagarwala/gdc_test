<?php $__env->startSection('head_title', getcong('privacy_policy_title').' | '.getcong('site_name') ); ?>

<?php $__env->startSection('head_url', Request::url()); ?>

<?php $__env->startSection("content"); ?>
 
<div class="tp-page-head" style="background:url(<?php echo e(URL::asset('upload/'.getcong('page_bg_image'))); ?>) no-repeat">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-header">
          <h1><?php echo e(getcong('privacy_policy_title')); ?></h1>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="tp-breadcrumb">
  <div class="container">
    <div class="row">
      <div class="col-md-8">
        <ol class="breadcrumb">
          <li><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
          <li class="active"><?php echo e(getcong('privacy_policy_title')); ?></li>
        </ol>
      </div>
    </div>
  </div>
</div>
<div class="main-container">
  <div class="container">
    <div class="row">
      <div class="col-md-12 content-right">
        <div class="row">
          <div class="col-md-12 aboutus" id="aboutus">

            <?php echo getcong('privacy_policy_description'); ?>

            
          </div>
           
        </div>
         
      </div>
    </div>
  </div>
</div>
 

<?php $__env->stopSection(); ?>

<?php echo $__env->make("app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>