<option value="">Select Sub Category</option>
<?php foreach($subcategories as $i => $subcategory): ?>    
                                 
        <option value="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->sub_category_name); ?></option> 
                                                   
<?php endforeach; ?>