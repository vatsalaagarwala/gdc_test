<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>

<div>
    Name: <?php echo $name?><br/>
    Email: <?php echo $email ?><br/>    
    Subject: <?php echo $subject ?><br/>
    Message: <?php echo $user_message ?><br/>
</div>

</body>
</html>