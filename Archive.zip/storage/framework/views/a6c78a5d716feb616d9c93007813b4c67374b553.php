<div class="footer">
  <div class="container">
    <div class="row">
      <div class="social-icon">
       <h2>Follow Us</h2>
        <ul>
          <li><a href="<?php echo e(getcong('facebook_url')); ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
          <li><a href="<?php echo e(getcong('twitter_url')); ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
          <li><a href="<?php echo e(getcong('gplus_url')); ?>" target="_blank"><i class="fa fa-google-plus"></i></a></li>
          <li><a href="<?php echo e(getcong('linkedin_url')); ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li>
        </ul>      
      </div>
      <div class="footer-nav-list">
        <ul>
           <li><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>          
           <li><a href="<?php echo e(URL::to('about')); ?>"><?php echo e(getcong('about_title')); ?></a></li>
           <li><a href="<?php echo e(URL::to('contact')); ?>"><?php echo e(getcong('contact_title')); ?></a></li>
           <li><a href="<?php echo e(URL::to('termsandconditions')); ?>"><?php echo e(getcong('terms_of_title')); ?></a></li>
           <li><a href="<?php echo e(URL::to('privacypolicy')); ?>"><?php echo e(getcong('privacy_policy_title')); ?></a></li>            
        </ul>
      </div>
    </div>
  </div>
</div>
<div class="tiny-footer">
  <div class="container">
    <div class="row">
      <div class="col-md-12">Copyright © <?php echo e(date('Y')); ?>. All Rights Reserved.</div>
    </div>
  </div>
</div>