<?php $__env->startSection("content"); ?>

  <!-- Page Header -->
                <div class="content bg-gray-lighter">
                    <div class="row items-push">
                        <div class="col-sm-7">
                            <h1 class="page-heading">
                               <?php echo e(isset($location->id) ? 'Edit Location ' : 'Add Location'); ?>

                            </h1>
                        </div>
                        <div class="col-sm-5 text-right hidden-xs">
                            <ol class="breadcrumb push-10-t">
                                <li><a href="<?php echo e(URL::to('admin/locations')); ?>">Location</a></li>
                                <li><a class="link-effect" href=""><?php echo e(isset($location->id) ? 'Edit Location ' : 'Add Location'); ?></a></li>
                            </ol>
                        </div>
                    </div>
                </div>
                <!-- END Page Header -->
                <!-- Page Content -->
                <div class="content content-boxed">
                    <div class="row">
                        <div class="col-sm-12 col-lg-12">
                            <div class="block">
                               <div class="block-content block-content-narrow"> 
                                <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger">
                                     <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <ul>
                                        <?php foreach($errors->all() as $error): ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                <?php endif; ?>
                                 <?php if(Session::has('flash_message')): ?>
                                                <div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                                                    <?php echo e(Session::get('flash_message')); ?>

                                                </div>
                                <?php endif; ?>
                                <?php echo Form::open(array('url' => array('admin/locations/addlocation'),'class'=>'form-horizontal padding-15','name'=>'location_form','id'=>'location_form','role'=>'form','enctype' => 'multipart/form-data')); ?> 
                                    <input type="hidden" name="id" value="<?php echo e(isset($location->id) ? $location->id : null); ?>">
                                    <div class="form-group">
                                        <label for="" class="col-sm-3 control-label">Location Name</label>
                                          <div class="col-sm-9">
                                            <input type="text" name="location_name" value="<?php echo e(isset($location->location_name) ? $location->location_name : null); ?>" class="form-control">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="" class="col-sm-3 control-label">Location Slug</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="location_slug" value="<?php echo e(isset($location->location_slug) ? $location->location_slug : null); ?>" class="form-control">
                                        </div>
                                    </div>
                                    
                                    <hr>
                                    <div class="form-group">
                                        <div class="col-md-offset-3 col-sm-9 ">
                                            <button type="submit" class="btn btn-primary"><?php echo e(isset($location->id) ? 'Edit Location ' : 'Add Location'); ?></button>
                                             
                                        </div>
                                    </div>
                                    
                                    <?php echo Form::close(); ?> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- END Page Content -->            
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.admin_app", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>