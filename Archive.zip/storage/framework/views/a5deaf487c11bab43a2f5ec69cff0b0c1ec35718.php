<?php $__env->startSection('content'); ?>
    <h1>Hello <?php echo e(Auth::user()->first_name); ?></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>